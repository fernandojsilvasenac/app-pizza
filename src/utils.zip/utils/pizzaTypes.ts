export const PIZZA_TYPES = [
  { id: 'p', name: 'Pequena' },
  { id: 'm', name: 'Média' },
  { id: 'g', name: 'Grande' },
];